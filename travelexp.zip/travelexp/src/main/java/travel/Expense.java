package travel;

public interface Expense {
	double calculateReimbursement();

}
